// import { useState } from "react"

const Exercise2 = () => {
    // const [game,setGame] = useState({
    //     id:1,
    //     player:{
    //         name:'john'
    //     }
    // })

    // const [req,setReq] = useState({
    //     name:'spicy',
    //     topping:['mushroom']
    // })
    // const s = 'something'
    
    // const [cart,setCart] = useState({
    //     discount:.1,
    //     items:[
    //         {id:1,title:'product1',quantity:1},
    //         {id:2,title:'product2',quantity:2}
    //     ]
    // })

    return(
        <>
            {/* <p>{game.id}</p>
            <p>{game.player.name}</p>
            <button onClick={()=>setGame({...game,player:{...game.player,name:game.player.name+'smith'}})}>Click</button> */}
            {/* <p>{req.name}</p>
            {req.topping.map(item=><p>{item}</p>)}
            <button onClick={()=>setReq({...req,topping:[...req.topping,s]})}>add topping</button> */}
            {/* {cart.items.map(item=>
                <div>
                    <p>{item.title}</p>
                    <p>{item.quantity}</p>
                </div>
            )}
            <button onClick={()=>setCart({...cart,items:cart.items.map(item=>
                item.id==1?{...item,quantity:item.quantity+1}:{...item})})}>Click</button>
            <button onClick={()=>setCart({...cart,items:cart.items.map(item=>
                item.id==2?{...item,quantity:item.quantity+1}:{...item})})}>Click</button> */}
        </>
    )
}

export default Exercise2