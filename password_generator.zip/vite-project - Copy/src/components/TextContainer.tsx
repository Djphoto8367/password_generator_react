import { useState } from "react"

interface Props{
    maxCount?:number,
    children:string
}

const TextContainer = ({children,maxCount=100}:Props) => {
    const [count,setCount] = useState(maxCount)
    return(
        <>
            <p>{children.slice(0,count+1)+ String(children.length==count?'':'...')}
                <button className="btn btn-primary mx-2" onClick={()=>setCount(children.length)}>expand</button>
                <button className="btn btn-primary" onClick={()=>setCount(maxCount)}>shrink</button>
            </p>
        </>
    )
}

export default TextContainer