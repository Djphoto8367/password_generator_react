import { useState } from "react";

interface Props{
    list:string[],
    click:(item:string)=>void
}

const ListGroup = ({list,click}:Props) => {
    // const list:string[] = ["item1","item2","item3","item4"]
    const [active,setActive] = useState(-1);
    const clicked = (index:number) => setActive(index)

    return(
        <>
        {/* <h1>{props.name}</h1> */}
        <h1>List Group</h1>
        <ul className="list-group">
            {list.map((item,index) => <li key={index} className={`list-group-item ${active==index?"active":""}`} onClick={()=>{clicked(index);click(item)}}>{item}</li>)}
        </ul>
        </>
    )
}

export default ListGroup; 