import { useEffect, useRef, useState } from "react";

const Password_genarator = () => {
    const range = useRef<HTMLInputElement>(null)
    const [chars,setChars] = useState('5')
    const [includenumber,setIncludenumber] = useState(false)
    const [includespecial,setIncludespecial] = useState(false)
    const [password,setPassword] = useState('AbYvI')
    const [copied,setCopied] = useState(false)

    useEffect(()=>{
        const list = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
        const numbers = '0123456789'
        const special = '!@$%^&*+#'
        let new_password:string = ''
        if(includenumber){
            new_password+=numbers[Math.floor(Math.random()*numbers.length)]
        }
        if(includespecial){
            new_password+=special[Math.floor(Math.random()*special.length)]
        }
        for(let i=0;i<parseInt(chars)-(includenumber?1:0)-(includespecial?1:0);i++){
            let rnum = Math.floor(Math.random() * list.length);
            new_password+=list[rnum]
        }
        setPassword(new_password)
    },[chars,includenumber,includespecial])

    const copytoclipboard = () => {
        navigator.clipboard.writeText(password)
        setCopied(true)
        setTimeout(()=>{
            setCopied(false)
        },2000)
    }

    return(
        <>
            <div className="container border col-lg-6 my-3 position-relative">
                <p className="fw-bold h3 text-center">Password genarator</p>
                {copied && <p className="position-absolute top-0 end-0 text-success px-4 py-2">copied</p>}
                <div className="d-flex justify-content-between w-100">
                    <input className="form-control w-75" type="text" value={password} disabled/>
                    <button className="btn btn-primary" onClick={copytoclipboard}>Copy</button>
                </div>
                <div className="d-md-flex justify-content-between w-75 my-3">
                        <div>
                            <input ref={range} className="mx-1" type="range" name="range" id="range" value={chars} onChange={()=>{setChars(String(range.current?.value))}}/>
                            <label htmlFor="range" className="pb-2">{chars}charecters</label>
                        </div>
                        <div>
                            <input className="mx-1" type="checkbox" name="number" id="number" onChange={()=>setIncludenumber(!includenumber)}/>
                            <label htmlFor="number">number</label>
                        </div>
                        <div>
                            <input className="mx-1" type="checkbox" name="special charecter" id="special_charecter" onChange={()=>setIncludespecial(!includespecial)}/>
                            <label htmlFor="special_charecter">special charecter</label>
                        </div>
                </div>
            </div>
        </>
    )
}

export default Password_genarator;